import React from "react";
import '../css/Terms.css';

const Terms = () => {
  return (
    <div>
      <div>
        <div className="term">
          <center>
            <h1>
              <span>Terms & Conditions</span>
            </h1>
          </center>
        </div>

        <div className="condition">
          <p>
            {" "}
            1.TNSTC provides only the facility for transacting with SETC and
            TNSTC’s Passenger Reservation System through the Internet. TNSTC’s
            rules for reservation and booking apply to all such transaction
            along with special conditions imposed for Internet based booking.
            The special conditions and terms of service applicable to Internet
            booking are detailed in this document. The following terms and
            conditions will apply if you wish to use the TNSTC’s online ticket
            booking service offered through the TNSTC website. Please go through
            the conditions carefully and if you accept them, you may register
            and transact on the site, you are deemed to have agreed to the terms
            and conditions set’ forth below. If you do not agree with these
            terms and conditions, you must not transact on this Website. Once
            you have clicked the ‘Agree’ button at the bottom of Terms and
            Conditions at login page, you have entered into a formal agreement
            with TNSTC for the purpose of transactions on this website. If a
            user violates the terms and conditions of use by registering more
            than one user ID and /or booking tickets on such multiple user IDs,
            TNSTC reserves the right to deactivate all such user registration
            and cancel any or all tickets booked using these registrations
            without any notice.
            <br />
            <br />
            2.TNSTC’s performance of this agreement is subject to existing laws
            and legal processes of Government of India and nothing contained in
            this agreement is in derogation of TNSTC’s right to comply with law
            enforcement requests or requirements relating to your use of this
            Web Site or information provided to or gathered by TNSTC with
            respect to such use. You agree that TNSTC may provide details of
            your use of the Web Site to regulators or police or to any other
            third party, or in order to resolve disputes or complaints which
            relate to the Web Site, at TNSTC’s complete discretion. If any part
            of this agreement is determined to be invalid or unenforceable
            pursuant to applicable law including, but not limited to, the
            warranty disclaimers and liability limitations set forth herein,
            then the invalid or unenforceable provision will be deemed
            superseded by a valid, enforceable provision that most closely
            matches the intent of the original provision and the remainder of
            the agreement shall continue in effect. This agreement constitutes
            the entire agreement between the customer and TNSTC with respect to
            this Web Site and it supersedes all prior or contemporaneous
            communications and proposals, whether electronic, oral, or written,
            between the customer and TNSTC with respect to this Web Site. A
            printed version of this agreement and of any notice given in
            electronic form shall be admissible in judicial or administrative
            proceedings based upon or relating to this agreement to the same
            extent and subject to the same conditions as other business
            documents and records originally generated and maintained in printed
            form. Boarding Points are provided for the benefit of reserved
            passengers.
            <br />
            <br />
            3.Instead of coming to Origin Point, the reserved passengers can
            board the bus in the en route boarding points. How ever, the fare
            will be collected from previous stage of the Boarding Point. It is
            the sole discretion of Management to Provide/ remove the stage or
            Boarding Points in any Route. The Reservation fee and other
            Applicable charges should be paid by the commuters in all the mode
            of bookings. Even the passengers who are availing the Concession
            like Senior Citizen or differently abled should pay the Reservation
            fee and other Applicable Charges.
            <br />
            <br />
            <b>Procedure for booking e-Ticket / Mobile tickets:</b>
            <br />
            1.Online Booking (Internet Booking) will enable the passenger to
            book the seats and cancel the ticket even from remote places where
            TNSTC Corporations Bus Services operates. The procedure and
            guidelines for Internet booking (called, Online booking) are
            detailed as below: Booking can be made by registered user through
            the Internet.
            <br />
            2.Registered User will be given username and password after filling
            an E-form on the Internet by giving his personal details. Tickets
            can be booked and Payments for tickets booked will have to be made
            through Credit card / Internet Banking.
            <br />
            3.Passenger booking the ticket will have to login to TNSTC website
            and proceed through the link provided for Advance Booking. The
            passenger will select the seats in a service of his choice based on
            the availability. During the booking process, the passenger will
            have to select Identity Type and submit ID No. for confirming his
            identity during the journey.
            <br />
            4.He can select from any of the Photo Identity Cards i.e. Passport,
            Driving License, Voter ID Card, PAN Card, Ration Card (passenger's).
            Before confirming the booking, the passenger will have to provide
            payment details like 'Credit Card / Internet Banking' for accepting
            payment by the Payment gateway.
            <br />
            5.The booking will be confirmed after the financial gateway approves
            the transaction. At this stage, a PNR No. will be generated for that
            ticket and passenger can print the e-Ticket / Mobile Ticket.
            <br />
            6.'e-Ticket / Mobile Tickets' will be printed on plain paper (A4
            size) for acknowledgement and it will be valid for journey. Please
            note that it is a must for passengers to carry Printed tickets done
            through e-Ticket / Mobile Ticket at the time of journey.
            Alternatively, the passenger will have the option of getting the
            'e-Ticket / Mobile Ticket' printed at any other place where he has
            Internet connectivity and printing facility.
            <br />
            7.He can print the 'e-Ticket / Mobile Ticket', by logging on through
            his User ID from “View Booking History” of login page.
            <br />
            8.If the passenger is travelling with 'e-Ticket / Mobile Ticket', he
            will have to produce the Original Identity Card mentioned in the
            'e-Ticket / Mobile Ticket ' at the time of journey.
            <br />
            9.The on-duty Conductor or TNSTC officials will verify the Identity
            Card of the passenger as per the waybill and 'e-Ticket / Mobile
            Ticket' during the journey. If the passenger fails to produce the
            specified Identity Proof in original during the journey, the ticket
            will be treated as INVALID and the passenger will be treated as
            "Travelling without Ticket". Photocopies of Identity proof are not
            allowed. Tickets booked through e-Ticket / Mobile Tickets will be
            allowed for cancellation before One hour of the scheduled departure.
            <br />
            10.For registered users, cancellation is allowed Online only if they
            login with the same user ID used for booking the ticket, which is to
            be cancelled. In respect of cancellations, refunds applicable will
            be made to the concerned Credit card / Internet banking account
            only.
            <br />
            11.
            <b>
              TNSTC Bus tickets can also be booked through www.busindia.com.
            </b>
            <br />
            12.Cancellation of e-tickets is only allowed one hour before the
            schedule departure of the service from originating point.
            <br />
            13.If the service is cancelled by TNSTC (or other STUs) for
            operational reasons, refund applicable will be made to the concerned
            Credit card / Internet banking account only.
            <br />
            14.If a passenger has lost the "e-Ticket / Mobile Ticket", copy of
            the same can be printed by logging on to "View Booking History"
            module through his User ID. No charges will be applicable.
            <br />
            15.All transactions made by the user through Online booking will be
            available in "View Booking History". This will be for the reference
            of the passenger and subsequent verification of transactions made on
            the concerned Credit card / Internet banking account.
            <br />
            16.All transactions on Internet are subject to the conditions
            stipulated by the Financial Gateway and subject to levy of charges,
            if any. The TNSTC will levy a service charge on the fare applicable
            for each seat in addition to the fare payable.
            <br />
            17.Users are advised to print e-Ticket / Mobile Tickets immediately
            after booking so as to minimize inconvenience during instances of
            temporary withdrawal of e-booking due to high traffic on website.
            The e-Ticket / Mobile Tickets will also be emailed to the email
            address provided by the user at the time of the booking. e-Ticket
            and Mobile Ticket Passengers must carry a printed ticket at the time
            of journey.
            <br />
            <b>Differently abled persons and their Escorts:</b>
            <p>
              Differently abled persons have to mention their valid ID card
              (issued by Govt.,) details while making Online Ticket Reservation.
              At the time of boarding the vehicle, a photocopy of the disablity
              Certificate has to be handed over to the Conductor and also the
              Original Certificate has to be carried by the Differently Abled
              person and shown to the Conductor. If any Escort is accompanying
              with the Differently abled person, the ID proof of such escort has
              also to be produced to the conductor. Applicable fare concessions
              for differently abled persons and their escort are automatically
              availed at the time of booking. * Differently Abled Concession is
              only Applicable within Tamilnadu State Travel.
            </p>
            <b>Senior Citizens:</b>
            <p>
              Fare concessions availed by senior citizens, have to produce
              original age proof ID cards at the time of journey like PAN card,
              Voter's ID, Driving license, Passport, Ration card, etc., At the
              time of boarding the vehicle, photocopy of the Age Proof ID has to
              be handed over to the Conductor.
            </p>
            <br />
            <b>Group Discount:</b>
            <p>
              Group Booking Discount - 10% Discount on basic fare is allowed
              when 10 or more seats are booked as a group in a single ticket. *
              Group discount is not applicable on Festival and Auspicious Travel
              Days. * In case of partial cancellations, if number of passengers
              after cancellations reduces to less than 10, group discount for
              all seats will be withdrawn. * Any one discount or concession will
              only be given to eligible passengers who make a reservation.
            </p>
            <br />
            <b>SMS Terms and Conditions:</b>
            <p>
              Short Messaging Service (SMS Service) offered by TNSTC is an
              additional facility to Passengers and also it is not mandatory
              service. SMS will be sent only to the mobile number you have
              registered/given during the advanced booking. The time to deliver
              the SMS is dependent upon the traffic on the mobile network and
              whether your mobile phone is within reach and switched on and
              cannot therefore be guaranteed by TNSTC. TNSTC is not liable for
              any delay or failures in the receipts of any SMS sent to reserved
              passengers in connection with their travel. Delivery of SMS
              (e-ticket, m-ticket, API-ticket, Journey bill alerts, service
              alerts etc.) depends on mobile service provider of the user and
              TNSTC is not responsible for its delivery. SMS Service such as
              e-ticket, m-ticket, API-ticket, Journey bill alerts etc., may be
              discontinued at any time without prior notice. By accepting the
              Terms and Conditions, you specifically acknowledge and agree to
              the aforesaid terms and conditions.
            </p>
            <br />
            <b>Refund Procedure:</b>
            <p>
              In respect of tickets cancelled by the passenger, TNSTC will
              refund the amount applicable to the concerned Credit card /
              Internet banking account by TNSTC. In case the ETicket was not
              booked but amount debited from your Bank account or Credit / Debit
              card, the amount would be credited back to your account / card
              within 15 working days. In case the amount is not credited in 15
              working days, please send a refund request letter to the
              Commercial Manager in the address below, quoting your User ID and
              Booking reference number (OB Number) of the transaction. SETC will
              not be responsible for refund delays from Bank side. In respect of
              refunds due to cancellation of service by TNSTC, passengers are
              required to send refund letter along with ticket copy to
              Commercial Manager to the address below, mentioning USERID of the
              passenger, OB reference no. of the transaction and PNR No. of the
              ticket. Officials of TNSTC will verify and refund the amount to
              the concerned Credit card / Internet banking account. In respect
              of refunds for any other reasons, passengers are required to send
              refund letter along with ticket copy to Commercial Manager to the
              address below, furnishing user ID of the passenger, OB reference
              no. of the transaction and PNR No. of the ticket mentioning
              reasons for such refund. However such requests will be considered
              only if received before the departure time of the service.
              Officials of TNSTC will examine the details and take appropriate
              action under intimation to the passenger. Refunds due to
              cancellation of tickets will be refunded normally in 2 weeks by
              TNSTC, after the cancellation of ticket or receipt of e-mail. If
              refunds are delayed, passengers may contact TNSTC officials at
              Help Desk telephone numbers provided in the website. In case of
              any service was cancelled by TNSTC's due to unavoidable
              circumstances and no alternate service was operated in place of
              the Cancelled services, then the passengers reserved in that
              particular service can get the refund by sending a refund claim
              letter along with the e-ticket copy to: The Deputy Manager
              (Commercial), State Express Transport Corporation Tamil Nadu Ltd.,
              "Thiruvalluvar House" No.2, Pallavan salai, Chennai - 600002.
            </p>
            <br />
            <b>Website Usage</b>
            <p>
              The content of the pages of this website is for your general
              information and use only. It is subject to change without notice.
              Your use of any information or materials on this website is
              entirely at your own risk, for which we shall not be liable. It
              shall be your own responsibility to ensure that any products,
              services or information available through this website meet your
              specific requirements. All trademarks reproduced in this website,
              which are not the property of, or licensed to the operator, are
              acknowledged on the website. Unauthorized use of this website may
              give rise to a claim for damages and/or be a criminal offence.
              Your use of this website and any dispute arising out of such use
              of the website is subject to the governing laws.
            </p>
            <br />
            <p>
              <b>For Bank Queries:pgsupport@billdesk.com</b>
            </p>
            <p>
              <b>For Reservation Related Queries:commercial@tnstc.in</b>
            </p>
          </p>
        </div>
      </div>
    </div>
  );
};

export default Terms;

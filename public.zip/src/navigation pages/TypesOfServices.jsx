import React from 'react'

const TypesOfServices = () => {
  return (
    <div>TypesOfServices</div>
  )
}

export default TypesOfServices
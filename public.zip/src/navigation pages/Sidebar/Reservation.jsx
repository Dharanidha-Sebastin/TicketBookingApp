import React from 'react'

const Reservation = () => {
  return (
    <div>Reservation</div>
  )
}

export default Reservation
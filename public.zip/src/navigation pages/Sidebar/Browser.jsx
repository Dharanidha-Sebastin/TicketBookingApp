import React from 'react'

const Browser = () => {
  return (
    <div>Browser</div>
  )
}

export default Browser
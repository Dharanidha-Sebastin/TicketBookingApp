import React from 'react'

const Information = () => {
  return (
    <div>Information</div>
  )
}

export default Information
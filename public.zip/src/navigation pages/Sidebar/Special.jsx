import React from 'react'

const Special = () => {
  return (
    <div>Special</div>
  )
}

export default Special
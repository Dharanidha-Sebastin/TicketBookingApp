import React from 'react'

const Hire = () => {
  return (
    <div>
      <p div="part1"> Home</p>
      <p div="part2">Hire-A-Bus</p>
    </div>
  )
}

export default Hire
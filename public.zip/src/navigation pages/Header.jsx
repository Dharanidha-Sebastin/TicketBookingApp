import React from 'react'
import { Outlet, Link } from "react-router-dom";
import bus from "./images/bus.jpg";
import center from "./images/center.jpg";
import mirror from "./images/mirror.jpg";
import "./Header.css";
import DoubleArrowIcon from '@mui/icons-material/DoubleArrow';

const Header = () => {
  return (
    <div className='header-layout'>
        {/* creating language bar */}
        <div className='header-language'>
            <p id='header-language-p'>English | Tamil</p>
        </div>

        {/* creating main logo */}
        <div className='header-logo-img'>
            <div className='header-bus'>
                <img src={bus} alt='bus' ></img>
            </div>

            <div className='header-center'>
                <img src={center} alt='center' ></img>
            </div>

            <div className='header-mirror'>
                <img src={mirror} alt='mirror' ></img>
            </div>
        </div>

        {/* creating nav bar */}
        <div className='header-nav'>
            <ul>
                <Link to="/">
                    <h3>Duplicate &nbsp;|</h3>
                </Link>
                <Link to="/About">
                    <h3>About Us &nbsp;|</h3>
                </Link>
                <Link to="/TypesOfServices">
                    <h3>Types of Services &nbsp;|</h3>
                </Link>
                <Link to="/Terms">
                    <h3>Terms & Conditions &nbsp;|</h3>
                </Link>
                <Link to="/Hire">
                    <h3>Hire a Bus &nbsp;|</h3>
                </Link>
                <Link to="/Gallery">
                    <h3>Gallery &nbsp;|</h3>
                </Link>
                <Link to="/Contact">
                    <h3>Contact Us &nbsp;|</h3>
                </Link>
            </ul>
        </div>

        {/* creating side sections */}
        <section>
            <div className='header-know-more'>
                <h4>Know More About </h4>
                <h6>..................................................................................</h6>
                <Link to="/Information">
                    <h3>Information</h3>
                </Link>
                <Link to="/Rules">
                    <h3> Rules & Regulations</h3>
                </Link>
                <Link to="/Reservation">
                    <h3>Reservation Center</h3>
                </Link>
                <Link to="/Special">
                    <h3>Special Services</h3>
                </Link>
            </div>

            <div className='header-General-info'>
                <h4>Counter Address</h4>
                <h6>..................................................................................</h6>
                <Link to="/Counter">
                    <h3>Counter Address</h3>
                </Link>
                <Link to="/Suggestions">
                    <h3> Suggestions</h3>
                </Link>
                <Link to="/Compatible">
                    <h3> Compatible Browsers</h3>
                </Link>
                <Link to="/Browser">
                    <h3>Browser Settings</h3>
                </Link>
                <Link to="/FAQs">
                    <h3>FAQs</h3>
                </Link>
                <Link to="/Privacy">
                    <h3>Privacy</h3>
                </Link>
            </div>
        </section>
        

        <Outlet />
    </div>
  )
}

export default Header
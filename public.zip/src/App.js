import { BrowserRouter, Routes, Route } from "react-router-dom";

import Header from "./navigation pages/Header";
import Duplicate from "./navigation pages/Duplicate";
import About from "./navigation pages/About";
import Gallery from "./navigation pages/Gallery";
import Hire from "./navigation pages/Hire";
import Terms from "./navigation pages/Terms";
import TypesOfServices from "./navigation pages/TypesOfServices";
import Contact from "./navigation pages/Contact";



import Information from "./navigation pages/Sidebar/Information";
import Rules from "./navigation pages/Sidebar/Rules";
import Reservation from "./navigation pages/Sidebar/Reservation";
import Special from "./navigation pages/Sidebar/Special";

import Counter from "./navigation pages/Sidebar/Counter";
import Suggestions from "./navigation pages/Sidebar/Suggestions";
import Compatible from "./navigation pages/Sidebar/Compatible";
import Browser from "./navigation pages/Sidebar/Browser";
import FAQs from "./navigation pages/Sidebar/FAQs";
import Privacy from "./navigation pages/Sidebar/Privacy";
import { Switch } from "@material-ui/core";

function App() {
  return (
    <div className="App">
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Header />}>
            <Route index element={<About />} />
            {/* <Route path="/Duplicate" element={<Duplicate />} /> */}
            <Route path="/Gallery" element={<Gallery />} />
            <Route path="/Hire" element={<Hire />} />
            <Route path="/Terms" element={<Terms />} />
            <Route path="/TypesOfServices" element={<TypesOfServices />} />
            <Route path="/Contact" element={<Contact />} />

            {/* for section pages */}
            <Route path="/Information" element={<Information />} />
            <Route path="/Rules" element={<Rules />} />
            <Route path="/Reservation" element={<Reservation />} />
            <Route path="/Special" element={<Special />} />

            <Route path="/Counter" element={<Counter />} />
            <Route path="/Suggestions" element={<Suggestions />} />
            <Route path="/Compatible" element={<Compatible />} />
            <Route path="/Browser" element={<Browser />} />
            <Route path="/FAQs" element={<FAQs />} />
            <Route path="/Privacy" element={<Privacy />} />
            </Route>
        </Routes>

        <Switch>
        <Route path="/Duplicate">
            <Duplicate />
          </Route>
        </Switch>


      </BrowserRouter>

    </div>

  );
}

export default App;

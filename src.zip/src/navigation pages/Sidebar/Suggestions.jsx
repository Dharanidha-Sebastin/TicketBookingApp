import React from 'react'

const Suggestions = () => {
  return (
    <div>Suggestions</div>
  )
}

export default Suggestions
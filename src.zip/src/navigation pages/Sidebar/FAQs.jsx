import React from 'react'

const FAQs = () => {
  return (
    <div>FAQs</div>
  )
}

export default FAQs
import React from 'react'

const Compatible = () => {
  return (
    <div>Compatible</div>
  )
}

export default Compatible
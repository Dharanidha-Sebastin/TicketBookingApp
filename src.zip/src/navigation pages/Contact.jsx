import React from 'react'
import '../css/Contact.css'

const Contact = () => {
  return (
    <div id='full-contact-content'>
      <div className='main'>
        <center>
      <p div id='home-tag'>Home&gt;Contact</p>
      <p div id='contact-tag'><b>Contact</b></p>
      <hr/>
      <address div id='address-tag'>
        <table>
            <center>
            <tr>
            <tbody>
                Address : State Express Transport Corporation Tamil Nadu Ltd.,<br/>
                        Head Office, Thiruvalluvar House,<br/>
                        Pallavan Salai,<br/>
                        Chennai - 600002.
            </tbody></tr>
            <tr>
                <tbody>
                    <div id='mail-block'>
                    email : swathi@gmail.com
                    </div>
                </tbody>
            </tr>
            <tr>
                <tbody>
                    <div id='number-block'>
                    Online Reservation Number : 108
                    </div>
                </tbody>
            </tr>
            </center>
        </table>
      </address>
      </center>
      </div>
    </div>
  )
}

export default Contact
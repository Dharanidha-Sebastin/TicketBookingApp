import React from 'react'
import "../css/Duplicate.css"

const Duplicate = () => {
  return (
    <div className='dop'>
      <h3>Duplicate</h3>
    </div>
  )
}

export default Duplicate
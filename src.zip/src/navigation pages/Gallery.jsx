import React from 'react'
import '../css/Gallery.css'
import image1 from '../busimage/image1.jpg';
import image2 from '../busimage/image2.jpg';

const Gallery = () => {
  return (
    <div>
      <div id='full'>
      <p div id='part1'>Home&gt;Gallery</p>
      <p div id='part2'>Photos</p>
      <hr/>
      <div id='empty'></div>
      <img id='part3' 
       src={image1} alt="image1"/>
      <img id='part4' 
      src={image2} alt="image2"/>
    </div>
    </div>
  )
}

export default Gallery